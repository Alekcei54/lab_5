import tkinter
from tkinter import messagebox

class TriangleCalculator(tkinter.Frame):
    """Graphical user interface and logic for calculating the perimeter of an isosceles triangle"""

    def __init__(self, parent):
        super().__init__(parent)
        self.pack(fill=tkinter.BOTH, expand=1)
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=1)

        self.lb1 = tkinter.Label(self, text="Enter base length a:")
        self.lb2 = tkinter.Label(self, text="Enter height h:")
        self.lb3 = tkinter.Label(self, text="Perimeter:")
        self.lb4 = tkinter.Label(self, text="sm")
        self.a_entr = tkinter.Entry(self)
        self.h_entr = tkinter.Entry(self)
        self.btn1 = tkinter.Button(self, text="Calculate perimeter", command=self.calc_perimeter)
        self.p_str = tkinter.StringVar()
        self.result_label = tkinter.Label(self, textvariable=self.p_str)

        self.lb1.grid(row=0, column=0, sticky=tkinter.NSEW)
        self.a_entr.grid(row=0, column=1, sticky=tkinter.NSEW)
        self.lb2.grid(row=1, column=0, sticky=tkinter.NSEW)
        self.h_entr.grid(row=1, column=1, sticky=tkinter.NSEW)
        self.btn1.grid(row=2, column=0, columnspan=2, sticky=tkinter.NSEW)
        self.lb3.grid(row=3, column=0, sticky=tkinter.NSEW)
        self.result_label.grid(row=3, column=1, sticky=tkinter.NSEW)
        self.lb4.grid(row=3, column=2, sticky=tkinter.NSEW)

    def calc_perimeter(self):
        try:
            a = float(self.a_entr.get())
            h = float(self.h_entr.get())
        except ValueError:
            messagebox.showerror("Data ERROR", "Side and height must be numbers!")
            self.a_entr.delete(0, tkinter.END)
            self.h_entr.delete(0, tkinter.END)
        else:
            if a < 0 or h < 0:
                a = abs(a)
                h = abs(h)
                self.a_entr.delete(0, tkinter.END)
                self.h_entr.delete(0, tkinter.END)
                self.a_entr.insert(tkinter.END, str(a))
                self.h_entr.insert(tkinter.END, str(h))
                messagebox.showinfo("Data Warning", "Negative values changed to positive")

            b = (a / 2) ** 2 + h ** 2
            b = b ** 0.5  # square root
            P = a + 2 * b
            self.p_str.set(f"{P:.2f}")